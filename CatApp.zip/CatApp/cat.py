import turtle

#This is responsible for creating cat objects.
class Cat:
    def __init__(self, name, age):
        self.name = name
        self.age = age
        
    def type(self, texture):
        fileName = texture #private variable
        gif = fileName + ".gif"

        #Registers the cat shape to display on the screen
        catTurtle = turtle.Turtle()
        window = turtle.Screen()
        window.addshape(gif)
        catTurtle.shape(gif)
        catTurtle.penup()

        return catTurtle
        
    def location(self, turtleObj, xcord, ycord):
        turtleObj.goto(xcord, ycord)



        

        

