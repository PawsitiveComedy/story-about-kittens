#----------------------------------------------------------
#This module is responsible for simulating a grocery store.
#The following stores can be accessed:
#       - CatMart
#----------------------------------------------------------

#CatMart Store
class CatMart:
    cats = 10


##############################
##############################
#Wallet
class Wallet:
    def __init__(self, money, driversLicense, coupons):
        self.money = money
        self.driversLicense = driversLicense
        self.coupons = coupons
    
#Grocery Cart
class GroceryCart:
    items = {}
    
#Basket
class Basket:
    items = {}
    
#Cash Register
class CashRegister:
    balance = 1000 #dollars
    receipt = {}
    
#Employee
class Employee:
    name = "Steve"
    age = 35
    occupation = "Manager"
    dialog = {}

#Holiday Mode
class HolidayMode:
    drinks = {"Egg Nog", "Ginger Ale", "Grape Juice"}
    desserts = {"Sherbert Ice Cream", "Gingerbread Cake", "Candy Cane Salad"}
    entrees = {"Turkey", "Egg Salad", "Fried Rice"}
    snacks = {"Fruit Snacks", "Chips & Dip", "Popcorn"}
    dairy = {"Parmesan Cheese", "Whipped Cream", "Paprika Yogurt"}
    produce = {"Mandarins", "Potatoes", "Apricots"}
    clothing = {"Pointy Hats", "Stockings", "Cat Gloves"}
    health = {"Mint Shampoo", "Candy Corn Toothpaste", "Bubblegum Floss"}

#Normal Mode
class NormalMode:
    drinks = {"Dr. Pepper", "Powerade", "ICE Sodas"}
    desserts = {"Brownies", "Cookies", "Donuts"}
    entrees = {"Pizza", "Lemon Pepper Chicken Nuggets", "Frozen Vegetables"}
    snacks = {"Trail Mix", "Fruit Bars", "Cheetos"}
    dairy = {"Milk", "Eggs", "Cheese"}
    produce = {"Apples", "Oranges", "Bell Peppers"}
    clothing = {"Shirts", "Socks", "Hats"}
    health = {"Shampoo", "Toothpaste", "Floss"}

